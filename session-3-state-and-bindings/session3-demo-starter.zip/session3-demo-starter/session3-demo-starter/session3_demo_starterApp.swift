//
//  session3_demo_starterApp.swift
//  session3-demo-starter
//
//  Created by Eugene Lo on 1/24/22.
//

import SwiftUI

@main
struct session3_demo_starterApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
