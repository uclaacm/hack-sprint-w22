//
//  ContentView.swift
//  session3-demo-starter
//
//  Created by Eugene Lo on 1/24/22.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        Text("Hello, world!")
            .padding()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
