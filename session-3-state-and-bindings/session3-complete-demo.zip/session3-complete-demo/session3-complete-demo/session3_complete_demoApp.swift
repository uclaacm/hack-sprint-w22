//
//  session3_complete_demoApp.swift
//  session3-complete-demo
//
//  Created by Eugene Lo on 1/18/22.
//

import SwiftUI

@main
struct session3_complete_demoApp: App {
  var body: some Scene {
    WindowGroup {
      ContentView()
    }
  }
}
